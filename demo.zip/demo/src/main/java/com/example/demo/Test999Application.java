package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Test999Application {

	public static void main(String[] args) {
		SpringApplication.run(Test999Application.class, args);
	}

}
